#include <iostream>
#include <fstream>
#include "word_analyzer.h"

using namespace std;

int main(int argc, char* argv[])
{
  if (argv[1] == NULL || argv[2] == NULL) {

    cout << "No hay suficientes argumentos, introduzca el fichero de entrada y/o de salida" << endl;

  } else {

    char *Entry_File = argv[1];
    char *Exit_File = argv[2];

    analyzer_t T;
    T.Comparation(Entry_File, Exit_File);
  }
}
