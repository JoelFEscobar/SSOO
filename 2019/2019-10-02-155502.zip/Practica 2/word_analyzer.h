#include <iostream>
#include <set>
#include <regex>
#include <ctype.h>
#include <fstream>
#include <sstream>

using namespace std;

class analyzer_t {

  private:

    set<string> special_;
    set<string> oper_;
    set<string> sign_;

  public:

    analyzer_t(void);
    ~analyzer_t(){}

    void Comparation(char* fich, char* fich2);
    void Write(char* file, string type, string pal);
    void Write_Special(char* file, string pal);
};


