/*
* PRACTICA DE SISTEMAS OPERATIVOS: NETCP.
*******************************************************************
* Autor: Joel Francisco Escobar Socas.
* Asignatura: Sistemas Operativos.
* Fichero: main -> Main encargado de toda la funcionalidad 
*******************************************************************
*/

#include "socket.h"



// ---------------> mejorar IP ADDRESS
 sockaddr_in make_ip_address(int port, const std::string& ip_address = std::string()){
    
    // Dirección del socket local
    sockaddr_in local_address{};	// Así se inicializa a 0, como se recomienda
    local_address.sin_family = AF_INET;	// Pues el socket es de dominio AF_INET
    local_address.sin_addr.s_addr = htonl(INADDR_ANY);
    local_address.sin_port = htons(port);

    return local_address;
 }



 int protected_main(){

/*
//abrimos el fichero
int open( const char* pathname, int flags )
int open( const char* pathname, int flags, mode_t mode )
int close( int fd )

//leemos y escribimos del fichero

ssize_t read(int fd, void* buf, size_t count)
ssize_t write(int fd, void* buf, size_t count)

*/

   // direccion del socket Bruno
   sockaddr_in dir_bruno = make_ip_address(3000);
   // direccion del socket Joel
   sockaddr_in dir_joel = make_ip_address(3004);

   //Creo los Sockets 
   Socket Bruno(dir_bruno);
   Socket Joel(dir_joel);

   //creo el mensaje y lo envio
   std::string message_text("¡Hola, mundo!");
   Message message;
   Message message2;

   message_text.copy(message.text.data(), message.text.size() - 1, 0);

   Bruno.send_to(message, dir_joel);
   //recibo el mensaje 
   Joel.receive_from(message2, dir_bruno);

   return 0;
  //message_text.copy(message.text.data(), message.text.size() - 1, 0);
  //Usar aqui el enviar_archivos
  /*
    std::string variable_arch;
    std::cout << "introduzca el nombre del archivo que desea abrir: \n";
    std::cin >> variable_arch;
   
    int comprobante = open( variable_arch.c_str() , O_RDONLY);
     if(comprobante < 0){
         std::cout<<"Error al abrir el archivo\n";
    }
    while(true){
    ssize_t verificacion = read(comprobante, &message.text, 1024);
    if(verificacion < 0 ){
        std::cout << "error al leer el fichero\n";
    }
    if(verificacion == 0){
        break;
    }
    Socket_enviar.send_to(message, dir_Socket_recibir);
   }
   close(comprobante);
*/

 }

 int main (void){
    try{
        protected_main();
    }

    catch(...){
        std::cout<<"error desconocido"<<'\n';
        return 123;
    }

 }