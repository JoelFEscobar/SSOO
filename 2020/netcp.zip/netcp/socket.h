/*
* PRACTICA DE SISTEMAS OPERATIVOS: NETCP.
*******************************************************************
* Autor: Joel Francisco Escobar Socas.
* Asignatura: Sistemas Operativos.
* Fichero: socket.h -> fichero encargado de declarar toda la funcionalidad de la clase socket.
*******************************************************************
*/
#pragma once

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/ip.h>
#include <netinet/in.h>
#include <iostream>
#include <cassert>
#include <cmath>
#include <vector>
#include <cstring>
#include <string>
#include <cstdlib>
#include <array>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h> 
#include <cerrno>
#include <arpa/inet.h>
#include <sys/mman.h>


struct Message {
    
	std::array<char, 1024> text;	// Igual que "char text[1024]"

};

class Socket {

    public:

    Socket(const sockaddr_in& address);
    ~Socket();
    void send_to(const Message& message, const sockaddr_in& address);
    void send_to(const void* puntero, const int length);

    void receive_from(Message& message, sockaddr_in& address);
    void recive_from(void* puntero, int length, file archivo, Message mensaje);

    private:
    int fd_;
    
};
