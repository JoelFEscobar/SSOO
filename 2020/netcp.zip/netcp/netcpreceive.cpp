/*
* PRACTICA DE SISTEMAS OPERATIVOS: NETCP.
*******************************************************************
* Autor: Socket_recibir Francisco Escobar Socas.
* Asignatura: Sistemas Operativos.
* Fichero: netcpsend.cpp -> Main encargado de enviar mensajes
*******************************************************************
*/
#include "socket.h"
#include "file.h"
// Definicion de la estructura de las IP

sockaddr_in make_ip_address(int port, const std::string& ip_address = std::string()){
    
    // Dirección del socket local
    sockaddr_in local_address{};	// Así se inicializa a 0, como se recomienda
    local_address.sin_family = AF_INET;	// Pues el socket es de dominio AF_INET
    local_address.sin_addr.s_addr = htonl(INADDR_ANY);
    local_address.sin_port = htons(port);

    return local_address;
}

// Main protegido con los try y catch

 int protected_main(){
   // direccion del socket Bruno
   sockaddr_in dir_Socket_enviar = make_ip_address(3000);
   // direccion del socket Socket_recibir
   sockaddr_in dir_Socket_recibir = make_ip_address(3004);

   //Creo los Sockets
   Socket Socket_recibir(dir_Socket_recibir);

   //creo el mensaje

    Message message2;
    std::string nombre_introducido;
    std::cout << "introduzca el nombre del archivo que desea nombrar: \n";
    std::cin >> nombre_introducido;

    file archivo(nombre_introducido, false);
    Socket_recibir.recive_from(archivo.getter_puntero(),archivo.getter_longitud(),archivo, message2);
   //recibo el mensaje 
   Socket_recibir.receive_from(message2, dir_Socket_enviar);

   return 0;

 }


 int main (void){
    try{
        protected_main();
    }

    catch(...){
        std::cout<<"error desconocido"<<'\n';
        return 123;
    }

 }