/*
* PRACTICA DE SISTEMAS OPERATIVOS: NETCP.
*******************************************************************
* Autor: Joel Francisco Escobar Socas.
* Asignatura: Sistemas Operativos.
* Fichero: netcpsend.cpp -> Main encargado de enviar mensajes
*******************************************************************
*/
#include "socket.h"
#include "file.h"
// Definicion de la estructura de las IP
sockaddr_in make_ip_address(int port, const std::string& ip_address = std::string()){
    
    // Dirección del socket local
    sockaddr_in local_address{};	// Así se inicializa a 0, como se recomienda
    local_address.sin_family = AF_INET;	// Pues el socket es de dominio AF_INET
    local_address.sin_addr.s_addr = htonl(INADDR_ANY);
    local_address.sin_port = htons(port);

    return local_address;
}

// Main protegido con los try y catch
 int protected_main(){
   // direccion del socket Socket_enviar
   sockaddr_in dir_Socket_enviar = make_ip_address(3000);
  // direccion del socket Socket_enviar
   sockaddr_in dir_Socket_recibir = make_ip_address(3004);
   //Creo los Sockets 
   Socket Socket_enviar(dir_Socket_enviar);

   //creo el mensaje y lo envio
   //std::string message_text("¡Hola, mundo!");
    Message message;
    ssize_t verificacion; 
        
    std::string variable_arch;
    std::cout << "Introduzca el nombre del archivo que desea abrir: \n";
    std::cin >> variable_arch;

    file fichero(variable_arch, true);
    Socket_enviar.send_to(fichero.getter_puntero(),fichero.getter_longitud());

    while(true){
        verificacion = fichero.leer(message);
        Socket_enviar.send_to(message, dir_Socket_recibir);
        if(verificacion == 0){
        break;
        }
    }

   return 0;
 }


 int main (void){
    try{
        protected_main();
    }

    catch(...){
        std::cout<<"error desconocido"<<'\n';
        return 123;
    }

 }